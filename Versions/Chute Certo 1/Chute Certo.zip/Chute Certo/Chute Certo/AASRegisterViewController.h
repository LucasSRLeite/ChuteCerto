//
//  AASRegisterViewController.h
//  Chute Certo
//
//  Created by Arthur Marques on 5/28/14.
//  Copyright (c) 2014 Arthur Augusto. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AASRegisterViewController : UIViewController <UINavigationControllerDelegate, UIImagePickerControllerDelegate, UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UITextField *textFieldName;
@property (weak, nonatomic) IBOutlet UITextField *textFieldEmail;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollViewRegister;

@property (weak, nonatomic) IBOutlet UIImageView *imageFotoUpload;

@property (weak, nonatomic) IBOutlet UIToolbar *toolbarPhoto;

- (IBAction)toolbarCameraButton:(id)sender;
- (IBAction)segmentedControlSexo:(UISegmentedControl *)sender;

@end
