//
//  AASMatchesTableViewCell.m
//  Chute Certo
//
//  Created by Arthur Marques on 5/28/14.
//  Copyright (c) 2014 Arthur Augusto. All rights reserved.
//

#import "AASMatchesGroupATableViewCell.h"
#import "AASMatchGameViewController.h"

@implementation AASMatchesGroupATableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
    }
    return self;
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (IBAction)buttonMatchOneAtion:(UIButton *)sender {
    [self showGameDetails : YES];
}

- (IBAction)buttonMatchTwoAction:(UIButton *)sender {
    [self showGameDetails : NO];
}

- (void) showGameDetails : (BOOL) isMatchOne {
    AASMatchGameViewController * viewController = [[AASMatchGameViewController alloc] init];
    viewController.labelGroupText = @"Grupo A";
    if (isMatchOne) {
        viewController.flagOneImagePath = @"Brazil Flag Original";
        viewController.flagTwoImagePath = @"Croatia Flag Original";
    } else {
        viewController.flagOneImagePath = @"Mexico Flag Original";
        viewController.flagTwoImagePath = @"Camaroes Flag Original";
    }
    [[[[UIApplication sharedApplication] delegate] window] setRootViewController:viewController];
}


@end
