//
//  Chute_CertoTests.m
//  Chute CertoTests
//
//  Created by Arthur Augusto Sousa Marques on 5/27/14.
//  Copyright (c) 2014 Arthur Augusto. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Chute_CertoTests : XCTestCase

@end

@implementation Chute_CertoTests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
